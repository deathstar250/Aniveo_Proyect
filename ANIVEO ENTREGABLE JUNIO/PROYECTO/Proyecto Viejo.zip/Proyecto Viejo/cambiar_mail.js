<html>
  <head>
    <div class="container">
      <div class="row"><h2>Cambiar el email</h2></div>
      <div class="row"><p class="text-justify">Email actual </p></div>
      <div class="row"><p class="text-justify">nombre@gmail.com</p></div>
      <div class="row"><p class="text-justify">Email nuevo</p></div>
      <div class="row"><input type="text" name="nombredelacaja"></div>
      <div class="row">
        <div class="col-md-3 col-3"style="background-color:blue"><p>Contraseña actual</p></div>
        <div class="col-md-3 col-3"style="background-color:red">  <a href="Cambiar_mail.js"><p aling="right">¿Olvidaste tu contraseña?</p></a></div>
        <div class="row"><input type="text" name="nombredelacaja"></div>
</br>
      </div>
      <button type="button">Guardar</button>   <button type="button">Cancelar</button>


    </div>
  </head>
  <body>
  </body>
</html>
